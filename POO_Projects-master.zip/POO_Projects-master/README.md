Ce projet est destiné à toute personne souhaitant apprendre la programmation
orientée objet. Les projets sont en Java, et ont été créés avec intelliJ idea
de JetBrains à but purement pédagogique, et sont les exercices du module POO
de l'Ecole nationale Supérieure d'Informatique 2017/2018.
